import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '감성 다이어리',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: CalendarScreen(),
    );
  }
}

class CalendarScreen extends StatefulWidget {
  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("감성 다이어리")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: TableCalendar(
          firstDay: DateTime(2000),
          lastDay: DateTime(2100),
          focusedDay: _focusedDay,
          selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDay = selectedDay;
              _focusedDay = focusedDay;
            });

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DiaryDetailScreen(selectedDay),
              ),
            );
          },
          calendarFormat: CalendarFormat.month,
          calendarStyle: const CalendarStyle(
            todayDecoration: BoxDecoration(
              color: Colors.pinkAccent,
              shape: BoxShape.circle,
            ),
            selectedDecoration: BoxDecoration(
              color: Colors.deepPurple,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class DiaryDetailScreen extends StatefulWidget {
  final DateTime selectedDate;

  const DiaryDetailScreen(this.selectedDate, {super.key});

  @override
  State<DiaryDetailScreen> createState() => _DiaryDetailScreenState();
}

class _DiaryDetailScreenState extends State<DiaryDetailScreen> {
  final TextEditingController _controller = TextEditingController();
  String? _savedDiary;

  @override
  void initState() {
    super.initState();
    _loadDiary();
  }

  Future<void> _loadDiary() async {
    final prefs = await SharedPreferences.getInstance();
    String key = widget.selectedDate.toIso8601String().split("T")[0];
    setState(() {
      _savedDiary = prefs.getString(key);
      _controller.text = _savedDiary ?? "";
    });
  }

  Future<void> _saveDiary() async {
    final prefs = await SharedPreferences.getInstance();
    String key = widget.selectedDate.toIso8601String().split("T")[0];
    await prefs.setString(key, _controller.text);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("일기가 저장되었습니다.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final formattedDate =
        "${widget.selectedDate.year}-${widget.selectedDate.month}-${widget.selectedDate.day}";

    return Scaffold(
      appBar: AppBar(title: const Text("일기 작성")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              "$formattedDate 의 일기를 작성하세요.",
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _controller,
              maxLines: 10,
              decoration: const InputDecoration(
                hintText: "오늘의 감정을 기록해보세요...",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveDiary,
              child: const Text("저장"),
            ),
          ],
        ),
      ),
    );
  }
}
