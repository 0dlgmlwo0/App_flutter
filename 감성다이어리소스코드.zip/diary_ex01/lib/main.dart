// 전체 UI 가독성 향상, 아이콘 색상 보정, 버튼 대비 강화, back 아이콘 명확히 보이도록 수정

import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '감성 다이어리',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'NanumPenScript',
        scaffoldBackgroundColor: const Color(0xFF1A1A40),
        textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      home: CalendarScreen(),
    );
  }
}

class CalendarScreen extends StatefulWidget {
  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Set<DateTime> _diaryDates = {};

  @override
  void initState() {
    super.initState();
    _loadDiaryDates();
  }

  Future<void> _loadDiaryDates() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys();
    setState(() {
      _diaryDates = keys
          .where((k) => !k.endsWith('_image') && !k.endsWith('_music'))
          .map((k) => DateTime.parse(k))
          .toSet();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌙 감성 다이어리'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple.shade700,
        leading: const Icon(Icons.menu, color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1A1A40), Color(0xFF0D0D2B)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: TableCalendar(
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            eventLoader: (day) {
              return _diaryDates.contains(DateTime(day.year, day.month, day.day))
                  ? ['diary']
                  : [];
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DiaryDetailScreen(selectedDay),
                ),
              ).then((_) => _loadDiaryDates());
            },
            calendarFormat: CalendarFormat.month,
            calendarStyle: CalendarStyle(
              todayDecoration: BoxDecoration(
                color: Colors.pinkAccent.shade100,
                shape: BoxShape.circle,
              ),
              selectedDecoration: const BoxDecoration(
                color: Colors.deepPurple,
                shape: BoxShape.circle,
              ),
              markerDecoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              defaultTextStyle: const TextStyle(color: Colors.white),
              weekendTextStyle: const TextStyle(color: Colors.white70),
            ),
            headerStyle: const HeaderStyle(
              formatButtonVisible: false,
              titleCentered: true,
              titleTextStyle: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DiaryDetailScreen extends StatefulWidget {
  final DateTime selectedDate;
  const DiaryDetailScreen(this.selectedDate, {super.key});
  @override
  State<DiaryDetailScreen> createState() => _DiaryDetailScreenState();
}

class _DiaryDetailScreenState extends State<DiaryDetailScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<String> musicList = [
    'up1.mp3', 'up2.mp3', 'up3.mp3',
    'down1.mp3', 'down2.mp3', 'down3.mp3',
  ];
  String? _savedDiary;
  String? _selectedMusic;
  File? _image;
  AudioPlayer? _audioPlayer;
  bool _isPlaying = false;

  @override
  void initState() {
    super.initState();
    _loadDiary();
  }

  Future<void> _loadDiary() async {
    final prefs = await SharedPreferences.getInstance();
    final key = widget.selectedDate.toIso8601String().split("T")[0];
    final text = prefs.getString(key);
    final imagePath = prefs.getString('${key}_image');
    final music = prefs.getString('${key}_music');

    setState(() {
      _savedDiary = text;
      _controller.text = text ?? '';
      _selectedMusic = music;
      if (imagePath != null && File(imagePath).existsSync()) {
        _image = File(imagePath);
      }
    });

    if (_selectedMusic != null && _selectedMusic!.isNotEmpty) {
      await _playMusic(_selectedMusic!);
    }
  }

  Future<void> _saveDiary() async {
    final prefs = await SharedPreferences.getInstance();
    final key = widget.selectedDate.toIso8601String().split("T")[0];
    await prefs.setString(key, _controller.text);
    await prefs.setString('${key}_music', _selectedMusic ?? '');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("일기가 저장되었습니다.")),
    );
    setState(() {
      _savedDiary = _controller.text;
    });
  }

  Future<void> _deleteDiary() async {
    final prefs = await SharedPreferences.getInstance();
    final key = widget.selectedDate.toIso8601String().split("T")[0];
    await prefs.remove(key);
    await prefs.remove('${key}_image');
    await prefs.remove('${key}_music');

    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, "$key.jpg"));
    if (file.existsSync()) {
      await file.delete();
    }

    if (_audioPlayer != null) {
      await _audioPlayer!.stop();
      await _audioPlayer!.dispose();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("일기가 삭제되었습니다.")),
    );
    Navigator.pop(context);
  }

  Future<void> _pickImage() async {
    if (kIsWeb) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("웹에서는 사진을 첨부할 수 없습니다.")),
      );
      return;
    }

    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      final file = File(picked.path);
      final key = widget.selectedDate.toIso8601String().split("T")[0];
      final savedPath = await _saveImage(file, key);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('${key}_image', savedPath);

      setState(() {
        _image = File(savedPath);
      });
    }
  }

  Future<String> _saveImage(File imageFile, String key) async {
    final dir = await getApplicationDocumentsDirectory();
    final filename = "$key.jpg";
    final savedPath = p.join(dir.path, filename);
    final savedImage = await imageFile.copy(savedPath);
    return savedImage.path;
  }

  Future<void> _playMusic(String filename) async {
    if (_audioPlayer != null) {
      await _audioPlayer!.stop();
      await _audioPlayer!.dispose();
    }
    _audioPlayer = AudioPlayer();
    await _audioPlayer!.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer!.play(AssetSource('music/$filename'));
    setState(() {
      _isPlaying = true;
    });
  }

  @override
  void dispose() {
    _audioPlayer?.dispose();
    super.dispose();
  }

  String _formatDate(DateTime date) {
    final weekdays = ['월', '화', '수', '목', '금', '토', '일'];
    return '${date.year}년 ${date.month}월 ${date.day}일 ${weekdays[date.weekday - 1]}요일';
  }

  @override
  Widget build(BuildContext context) {
    final formattedDate = _formatDate(widget.selectedDate);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple.shade700,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("🌌 감성 일기"),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1A1A40), Color(0xFF0D0D2B)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                formattedDate,
                style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Card(
                  color: Colors.white,
                  elevation: 10,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: ListView(
                      children: [
                        TextField(
                          controller: _controller,
                          maxLines: 10,
                          style: const TextStyle(fontSize: 18),
                          decoration: const InputDecoration(
                            hintText: "밤하늘을 바라보며 오늘의 이야기를 써보세요...",
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField<String>(
                          value: _selectedMusic,
                          decoration: InputDecoration(
                            labelText: '🎵 음악 선택',
                            filled: true,
                            fillColor: Colors.deepPurple.shade100,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: musicList.map((music) {
                            return DropdownMenuItem(
                              value: music,
                              child: Text(music),
                            );
                          }).toList(),
                          onChanged: (value) async {
                            setState(() => _selectedMusic = value);
                            await _playMusic(value!);
                          },
                        ),
                        const SizedBox(height: 16),
                        if (_image != null && !kIsWeb)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(_image!, height: 200, fit: BoxFit.cover),
                          ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const Icon(Icons.save),
                                label: const Text("저장"),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.deepPurple,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                onPressed: _saveDiary,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const Icon(Icons.photo),
                                label: const Text("사진"),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.purpleAccent,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                onPressed: _pickImage,
                              ),
                            ),
                            const SizedBox(width: 10),
                            if (_isPlaying)
                              Expanded(
                                child: ElevatedButton.icon(
                                  icon: const Icon(Icons.stop_circle),
                                  label: const Text("음악 끄기"),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.grey[800],
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                  onPressed: () async {
                                    await _audioPlayer?.stop();
                                    setState(() => _isPlaying = false);
                                  },
                                ),
                              ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
              if (_savedDiary?.isNotEmpty == true)
                Align(
                  alignment: Alignment.bottomRight,
                  child: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red, size: 30),
                    onPressed: _deleteDiary,
                    tooltip: '일기 삭제',
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
