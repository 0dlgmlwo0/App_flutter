package com.example.diary_ex01;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
